package com.paraiso.dashboard.repository;

import com.paraiso.dashboard.model.UserModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserModel,Long> {

  boolean existsByEmail(String email);
  boolean existsByName(String name);
}
