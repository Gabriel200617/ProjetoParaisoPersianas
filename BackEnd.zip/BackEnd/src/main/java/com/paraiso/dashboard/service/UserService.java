package com.paraiso.dashboard.service;

import com.paraiso.dashboard.dto.UserResponseDTO;
import com.paraiso.dashboard.model.UserModel;
import com.paraiso.dashboard.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

  private final UserRepository userRepository;
  private final PasswordEncoder passwordEncoder;

  public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder){
    this.userRepository = userRepository;
    this.passwordEncoder = passwordEncoder;
  }

  private final int TAMANHO_MINIMO_SENHA = 8;
  private final int TAMANHO_MAXIMO_NOME = 100;

  public UserResponseDTO registrarUser(UserResponseDTO dto){
    String name = dto.name() == null ? "" : dto.name().trim();
    if (name.isEmpty()){
      throw new IllegalArgumentException("Por favor, informe um nome");
    }
    if (name.contains("@")){
      throw new IllegalArgumentException("Nome não pode conter simbolos");
    }
    if (name.length() > TAMANHO_MAXIMO_NOME){
      throw new IllegalArgumentException("Maximo de caracteres alcançado");
    }
    if (dto.email() == null || dto.email().isEmpty()){
      throw new IllegalArgumentException("Por favor, informe um email");
    }
    String email = dto.email() == null ? "" : dto.email();
    if (userRepository.existsByEmail(email)){
      throw new IllegalArgumentException("Esse email já existe");
    }

    if(dto.password() == null || dto.password().isEmpty() || dto.password().length() < TAMANHO_MINIMO_SENHA){
      throw new IllegalArgumentException("A senha tem que possui no minimo "+ TAMANHO_MINIMO_SENHA+" caracteres");
    }

    UserModel userModel = new UserModel(
      name,
      email,
      passwordEncoder.encode(dto.password())
    );
    UserModel salvo = userRepository.save(userModel);
    return new UserResponseDTO(salvo.getId, salvo.getName, salvo.getEmail();
  }

  

}
